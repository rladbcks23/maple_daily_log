
  # 데스크톱 앱 UI 구상

  This is a code bundle for 데스크톱 앱 UI 구상. The original project is available at https://www.figma.com/design/XNUVSSTH3J0DtCyMeFplMQ/%EB%8D%B0%EC%8A%A4%ED%81%AC%ED%86%B1-%EC%95%B1-UI-%EA%B5%AC%EC%83%81.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  