import { useState } from "react";
import {
  User,
  Sword,
  Star,
  Calendar,
  ChevronRight,
  ChevronLeft,
  Bell,
  Settings,
  RefreshCw,
  Zap,
  Target,
  Award,
  BarChart2,
  Map,
  Package,
  Clock,
  CheckCircle2,
  XCircle,
  X,
  ChevronUp,
  Shield,
  Tag,
  Plus,
  Users,
  TrendingUp,
  TrendingDown,
  FileText,
  Minus,
} from "lucide-react";

// ─── Data ───────────────────────────────────────────────────────────────────

const ALL_TAGS = ["메인", "파밍", "보스", "육성중", "방치", "서브"] as const;
type TagName = typeof ALL_TAGS[number];

const TAG_COLOR: Record<TagName, string> = {
  "메인":   "bg-amber-500/20 text-amber-400 border-amber-500/30",
  "파밍":   "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  "보스":   "bg-red-500/20 text-red-400 border-red-500/30",
  "육성중": "bg-sky-500/20 text-sky-400 border-sky-500/30",
  "방치":   "bg-zinc-500/20 text-zinc-400 border-zinc-500/30",
  "서브":   "bg-violet-500/20 text-violet-400 border-violet-500/30",
};

const JOB_CLASSES = ["전체", "전사", "마법사", "궁수", "도적", "해적"] as const;
const MAIN_STATS  = ["전체", "STR", "DEX", "INT", "LUK"] as const;

const CHARACTERS = [
  {
    id: 1,
    name: "아케인아처",
    job: "아크",
    jobDetail: "아크",
    jobClass: "궁수" as const,
    mainStat: "DEX" as const,
    tags: ["메인", "보스"] as TagName[],
    level: 283,
    world: "크로아",
    combatPower: 34_810_630,
    guild: "파이어엠블",
    exp: 78,
    image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=80&h=80&fit=crop&auto=format",
    stats: { STR: 41681, DEX: 3984, INT: 2034, LUK: 2022 },
    hp: 75598,
    mp: 45856,
    starforce: 22,
    arcaneForce: 1380,
    sacredForce: 320,
    hyperStats: [
      { name: "STR", level: 4 }, { name: "DEX", level: 2 }, { name: "INT", level: 0 },
      { name: "LUK", level: 0 }, { name: "HP", level: 0 }, { name: "MP", level: 0 },
      { name: "DF/TF", level: 0 }, { name: "크리티컬 확률", level: 9 },
      { name: "크리티컬 데미지", level: 10 }, { name: "방어율 무시", level: 3 },
      { name: "데미지", level: 11 }, { name: "보스 데미지", level: 0 },
      { name: "상태이상 내성", level: 0 }, { name: "공격력/마력", level: 6 },
      { name: "획득 경험치", level: 15 }, { name: "아케인포스", level: 0 },
      { name: "일반 데미지", level: 11 },
    ],
    abilities: [
      { text: "아이템 드롭률 18% 증가", grade: "레전드리" },
      { text: "LUK 26 증가, STR 13 증가", grade: "유니크" },
      { text: "일반 몬스터 공격 시 데미지 8% 증가", grade: "에픽" },
    ],
    detailStats: [
      { label: "최대 스탯 공격력", value: "28,772,154", label2: "데미지", value2: "97.00%" },
      { label: "최종 데미지", value: "84.01%", label2: "보스 몬스터 데미지", value2: "340.00%" },
      { label: "방어율 무시", value: "95.13%", label2: "일반 몬스터 데미지", value2: "229.00%" },
      { label: "공격력", value: "2,735", label2: "크리티컬 확률", value2: "104%" },
      { label: "마력", value: "1,051", label2: "크리티컬 데미지", value2: "92.10%" },
      { label: "재사용 대기시간 감소", value: "0초 / 5%", label2: "버프 지속시간", value2: "60%" },
      { label: "재사용 대기시간 미적용", value: "0%", label2: "속성 내성 무시", value2: "0.00%" },
      { label: "상태이상 추가 데미지", value: "0.00%", label2: "소환수 지속시간 증가", value2: "15%" },
      { label: "메소 획득량", value: "20%", label2: "스타포스", value2: "303" },
      { label: "아이템 드롭률", value: "62%", label2: "아케인포스", value2: "1,380" },
      { label: "추가 경험치 획득", value: "297.50%", label2: "어센틱포스", value2: "320" },
      { label: "방어력", value: "75,588", label2: "상태이상 내성", value2: "43" },
      { label: "이동속도", value: "160%", label2: "점프력", value2: "123%" },
      { label: "스탠스", value: "100%", label2: "공격 속도", value2: "8단계" },
    ],
    arcaneSymbols: [
      { name: "소타스", level: 20, exp: 7890, maxExp: 9999, force: 90 },
      { name: "셀라스", level: 18, exp: 5430, maxExp: 9999, force: 82 },
      { name: "칼로스", level: 17, exp: 3210, maxExp: 9999, force: 78 },
      { name: "아르카나", level: 15, exp: 1200, maxExp: 9999, force: 70 },
      { name: "모라스", level: 12, exp: 800, maxExp: 9999, force: 58 },
      { name: "에스페라", level: 10, exp: 400, maxExp: 9999, force: 50 },
    ],
    sacredSymbols: [
      { name: "세르니움", level: 11, exp: 6540, maxExp: 9999, force: 55 },
      { name: "호텔 아르크스", level: 9, exp: 3210, maxExp: 9999, force: 45 },
      { name: "이글아이", level: 7, exp: 1890, maxExp: 9999, force: 35 },
      { name: "선샤인", level: 5, exp: 900, maxExp: 9999, force: 25 },
      { name: "카르시온", level: 3, exp: 400, maxExp: 9999, force: 15 },
    ],
  },
  {
    id: 2,
    name: "다크로드",
    job: "나이트로드",
    jobDetail: "나이트로드",
    jobClass: "도적" as const,
    mainStat: "LUK" as const,
    tags: ["서브", "파밍"] as TagName[],
    level: 261,
    world: "크로아",
    combatPower: 12_980_220,
    guild: "파이어엠블",
    exp: 45,
    image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=80&h=80&fit=crop&auto=format",
    stats: { STR: 680, DEX: 29100, INT: 540, LUK: 68400 },
    hp: 88000,
    mp: 14000,
    starforce: 17,
    arcaneForce: 640,
    sacredForce: 0,
    hyperStats: [
      { name: "LUK", level: 10 }, { name: "크리티컬 확률", level: 7 },
      { name: "데미지", level: 9 }, { name: "보스 데미지", level: 8 },
    ],
    abilities: [
      { text: "DEX 30 증가, LUK 20 증가", grade: "유니크" },
      { text: "이동속도 10 증가", grade: "에픽" },
    ],
    detailStats: [
      { label: "최대 스탯 공격력", value: "9,120,440", label2: "데미지", value2: "64.00%" },
      { label: "최종 데미지", value: "62.10%", label2: "보스 몬스터 데미지", value2: "210.00%" },
    ],
    arcaneSymbols: [
      { name: "소타스", level: 15, exp: 4500, maxExp: 9999, force: 70 },
      { name: "셀라스", level: 12, exp: 2100, maxExp: 9999, force: 58 },
    ],
    sacredSymbols: [],
  },
  {
    id: 3,
    name: "불꽃마법사",
    job: "불독",
    jobDetail: "불/독 아크메이지",
    jobClass: "마법사" as const,
    mainStat: "INT" as const,
    tags: ["육성중"] as TagName[],
    level: 244,
    world: "크로아",
    combatPower: 7_620_140,
    guild: "파이어엠블",
    exp: 62,
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=80&h=80&fit=crop&auto=format",
    stats: { STR: 240, DEX: 310, INT: 54280, LUK: 880 },
    hp: 52000,
    mp: 40000,
    starforce: 14,
    arcaneForce: 480,
    sacredForce: 0,
    hyperStats: [
      { name: "INT", level: 10 }, { name: "크리티컬 데미지", level: 8 },
      { name: "데미지", level: 7 },
    ],
    abilities: [
      { text: "INT 30 증가", grade: "에픽" },
    ],
    detailStats: [
      { label: "최대 스탯 공격력", value: "5,440,220", label2: "데미지", value2: "52.00%" },
    ],
    arcaneSymbols: [
      { name: "소타스", level: 10, exp: 1200, maxExp: 9999, force: 50 },
    ],
    sacredSymbols: [],
  },
  {
    id: 4,
    name: "강철팔라딘",
    job: "팔라딘",
    jobDetail: "팔라딘",
    jobClass: "전사" as const,
    mainStat: "STR" as const,
    tags: ["방치"] as TagName[],
    level: 230,
    world: "크로아",
    combatPower: 3_450_000,
    guild: "파이어엠블",
    exp: 22,
    image: "https://images.unsplash.com/photo-1608889175123-8ee362201f81?w=80&h=80&fit=crop&auto=format",
    stats: { STR: 38400, DEX: 920, INT: 560, LUK: 440 },
    hp: 180000,
    mp: 12000,
    starforce: 12,
    arcaneForce: 280,
    sacredForce: 0,
    hyperStats: [
      { name: "STR", level: 9 }, { name: "데미지", level: 6 }, { name: "보스 데미지", level: 5 },
    ],
    abilities: [
      { text: "STR 30 증가", grade: "에픽" },
    ],
    detailStats: [
      { label: "최대 스탯 공격력", value: "2,110,500", label2: "데미지", value2: "44.00%" },
    ],
    arcaneSymbols: [],
    sacredSymbols: [],
  },
  {
    id: 5,
    name: "썬더바이퍼",
    job: "바이퍼",
    jobDetail: "바이퍼",
    jobClass: "해적" as const,
    mainStat: "STR" as const,
    tags: ["육성중", "서브"] as TagName[],
    level: 218,
    world: "크로아",
    combatPower: 1_820_000,
    guild: "",
    exp: 55,
    image: "https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=80&h=80&fit=crop&auto=format",
    stats: { STR: 22100, DEX: 680, INT: 340, LUK: 420 },
    hp: 120000,
    mp: 8000,
    starforce: 8,
    arcaneForce: 120,
    sacredForce: 0,
    hyperStats: [
      { name: "STR", level: 5 }, { name: "데미지", level: 4 },
    ],
    abilities: [
      { text: "공격력 20 증가", grade: "레어" },
    ],
    detailStats: [
      { label: "최대 스탯 공격력", value: "880,200", label2: "데미지", value2: "28.00%" },
    ],
    arcaneSymbols: [],
    sacredSymbols: [],
  },
];

const EQUIP_SLOTS: { slot: string; row: number; col: number }[] = [
  { slot: "훈장", row: 1, col: 1 }, { slot: "모자", row: 1, col: 3 }, { slot: "반지4", row: 1, col: 5 },
  { slot: "얼굴장식", row: 2, col: 1 }, { slot: "눈장식", row: 2, col: 2 }, { slot: "목걸이", row: 2, col: 4 }, { slot: "반지3", row: 2, col: 5 },
  { slot: "귀걸이", row: 3, col: 1 }, { slot: "상의", row: 3, col: 3 }, { slot: "보조무기", row: 3, col: 5 },
  { slot: "어깨", row: 4, col: 2 }, { slot: "하의", row: 4, col: 3 }, { slot: "반지2", row: 4, col: 5 },
  { slot: "배지", row: 5, col: 1 }, { slot: "벨트", row: 5, col: 3 }, { slot: "반지1", row: 5, col: 5 },
  { slot: "장갑", row: 6, col: 2 }, { slot: "엠블렘", row: 6, col: 4 },
  { slot: "신발", row: 7, col: 2 }, { slot: "무기", row: 7, col: 3 }, { slot: "망토", row: 7, col: 4 }, { slot: "포켓", row: 7, col: 5 },
];

const EQUIPMENT_DATA: Record<string, {
  name: string; stars: number; potential: string; enhancement: string;
  mainStat: string; attackPower: number; description: string;
}> = {
  "모자": { name: "앱솔랩스 아처헬름", stars: 22, potential: "레전드리", enhancement: "+9", mainStat: "DEX +312", attackPower: 0, description: "DEX +312\n최종 데미지 +12%\nDEX % +9%" },
  "상의": { name: "앱솔랩스 아처아머", stars: 21, potential: "레전드리", enhancement: "+8", mainStat: "DEX +280", attackPower: 0, description: "DEX +280\n최종 데미지 +12%\nDEX % +6%" },
  "하의": { name: "앱솔랩스 아처팬츠", stars: 20, potential: "유니크", enhancement: "+7", mainStat: "DEX +210", attackPower: 0, description: "DEX +210\nDEX % +9%\n올스탯 +15" },
  "장갑": { name: "앱솔랩스 아처글러브", stars: 21, potential: "레전드리", enhancement: "+8", mainStat: "공격력 +9%", attackPower: 248, description: "공격력 +9%\n크리티컬 데미지 +8%\n보스 몬스터 공격 시 데미지 +30%" },
  "신발": { name: "앱솔랩스 아처슈즈", stars: 19, potential: "유니크", enhancement: "+6", mainStat: "DEX +180", attackPower: 0, description: "DEX +180\nDEX % +9%\n이동속도 +10" },
  "무기": { name: "에테르넬 보우", stars: 22, potential: "레전드리", enhancement: "+9", mainStat: "공격력 +3,240", attackPower: 3240, description: "공격력 +3,240\n보스 몬스터 공격 시 데미지 +30%\n방어율 무시 +30%\n최종 데미지 +12%" },
  "보조무기": { name: "에테르넬 화살통", stars: 22, potential: "레전드리", enhancement: "+9", mainStat: "공격력 +2%", attackPower: 180, description: "공격력 +2%\n보스 몬스터 공격 시 데미지 +30%\n방어율 무시 +30%" },
  "어깨": { name: "앱솔랩스 아처숄더", stars: 17, potential: "레전드리", enhancement: "+5", mainStat: "DEX +120", attackPower: 0, description: "DEX +120\n최종 데미지 +12%\nDEX % +6%" },
  "망토": { name: "앱솔랩스 아처케이프", stars: 18, potential: "유니크", enhancement: "+6", mainStat: "DEX +140", attackPower: 0, description: "DEX +140\nDEX % +6%\n올스탯 +10" },
  "벨트": { name: "타이탄의 허리띠", stars: 15, potential: "레전드리", enhancement: "+5", mainStat: "DEX +90", attackPower: 0, description: "DEX +90\n최종 데미지 +9%\n올스탯 +30" },
  "반지1": { name: "앱솔랩스 아처링", stars: 17, potential: "유니크", enhancement: "+4", mainStat: "DEX +60", attackPower: 0, description: "DEX +60\nDEX % +6%\n올스탯 +10" },
  "반지2": { name: "마이스터 반지", stars: 0, potential: "유니크", enhancement: "", mainStat: "공격력 +20", attackPower: 20, description: "공격력 +20\n스타포스 강화 불가" },
  "목걸이": { name: "앱솔랩스 아처펜던트", stars: 18, potential: "레전드리", enhancement: "+6", mainStat: "DEX +150", attackPower: 0, description: "DEX +150\n최종 데미지 +12%\nDEX % +6%" },
  "귀걸이": { name: "보스 귀걸이", stars: 17, potential: "에픽", enhancement: "+5", mainStat: "DEX +80", attackPower: 0, description: "DEX +80\nDEX % +4%" },
  "얼굴장식": { name: "붉은 진실의 눈물방울", stars: 12, potential: "유니크", enhancement: "+3", mainStat: "올스탯 +20", attackPower: 0, description: "올스탯 +20\nDEX % +6%" },
  "눈장식": { name: "비전의 눈", stars: 11, potential: "에픽", enhancement: "+3", mainStat: "DEX +30", attackPower: 0, description: "DEX +30\nDEX % +3%" },
  "엠블렘": { name: "황금 아처의 메달", stars: 0, potential: "레전드리", enhancement: "", mainStat: "공격력 +9%", attackPower: 0, description: "공격력 +9%\n방어율 무시 +30%\n최종 데미지 +12%" },
  "배지": { name: "수호의 배지", stars: 0, potential: "유니크", enhancement: "", mainStat: "올스탯 +15", attackPower: 0, description: "올스탯 +15\n공격력 +10\n방어력 +100" },
  "훈장": { name: "탐험가의 훈장", stars: 0, potential: "레전드리", enhancement: "", mainStat: "DEX +30", attackPower: 0, description: "DEX +30\n올스탯 +5\n올스탯 % +5%" },
  "포켓": { name: "핑크빈 카드", stars: 0, potential: "레전드리", enhancement: "", mainStat: "올스탯 +30", attackPower: 0, description: "올스탯 +30\n공격력/마력 +10\n올스탯 % +3%" },
};

const BOSSES = [
  { name: "카오스 벨룸", difficulty: "카오스", resetType: "주간", done: true, recommended: 200 },
  { name: "카오스 핑크빈", difficulty: "카오스", resetType: "주간", done: true, recommended: 160 },
  { name: "진 힐라", difficulty: "하드", resetType: "주간", done: false, recommended: 220 },
  { name: "듄켈", difficulty: "하드", resetType: "주간", done: false, recommended: 230 },
  { name: "루시드", difficulty: "하드", resetType: "주간", done: true, recommended: 220 },
  { name: "윌", difficulty: "하드", resetType: "주간", done: false, recommended: 230 },
  { name: "더스크", difficulty: "카오스", resetType: "주간", done: false, recommended: 235 },
  { name: "데미안", difficulty: "하드", resetType: "주간", done: true, recommended: 210 },
  { name: "카링", difficulty: "하드", resetType: "주간", done: false, recommended: 240 },
  { name: "혼테일", difficulty: "노말", resetType: "일간", done: true, recommended: 100 },
  { name: "자쿰", difficulty: "카오스", resetType: "일간", done: false, recommended: 150 },
];

const CONTENT = [
  { name: "아케인리버 일퀘", type: "일일", done: true, reward: "아케인심볼 조각" },
  { name: "세르니움 일퀘", type: "일일", done: true, reward: "성스러운심볼 조각" },
  { name: "호텔 아르크스 일퀘", type: "일일", done: false, reward: "성스러운심볼 조각" },
  { name: "이글아이 특수 일퀘", type: "일일", done: false, reward: "성스러운심볼 조각" },
  { name: "급지탐험대 일퀘", type: "일일", done: true, reward: "아케인심볼 조각" },
  { name: "무릉 도장", type: "주간", done: false, reward: "무릉 포인트" },
  { name: "레헬른 일퀘", type: "일일", done: true, reward: "아케인심볼 조각" },
];

const NAV_ITEMS = [
  { id: "dashboard", label: "대시보드", icon: BarChart2 },
  { id: "characters", label: "캐릭터", icon: User },
  { id: "equipment", label: "장비", icon: Sword },
  { id: "boss", label: "보스", icon: Target },
  { id: "content", label: "콘텐츠", icon: Calendar },
  { id: "report", label: "리포트", icon: FileText },
];

// ─── Report Data ─────────────────────────────────────────────────────────────

interface DayReport {
  combatPowerDelta: number;
  starforceDelta: number;
  levelDelta: number;
  note?: string;
}

// Mock report data for July 2026 (day → report)
const REPORT_DATA: Record<string, DayReport> = {
  "2026-7-1":  { combatPowerDelta: 0,        starforceDelta: 0,  levelDelta: 0,  note: "월간 시작" },
  "2026-7-2":  { combatPowerDelta: 124000,   starforceDelta: 0,  levelDelta: 1 },
  "2026-7-3":  { combatPowerDelta: 380000,   starforceDelta: 1,  levelDelta: 0,  note: "스타포스 +1" },
  "2026-7-4":  { combatPowerDelta: 0,        starforceDelta: 0,  levelDelta: 1 },
  "2026-7-5":  { combatPowerDelta: -42000,   starforceDelta: -1, levelDelta: 0,  note: "스타포스 터짐 😢" },
  "2026-7-6":  { combatPowerDelta: 890000,   starforceDelta: 2,  levelDelta: 1 },
  "2026-7-7":  { combatPowerDelta: 210000,   starforceDelta: 0,  levelDelta: 1 },
  "2026-7-8":  { combatPowerDelta: 1_240_000, starforceDelta: 0,  levelDelta: 0, note: "장비 교체" },
  "2026-7-9":  { combatPowerDelta: 65000,    starforceDelta: 0,  levelDelta: 1 },
  "2026-7-10": { combatPowerDelta: 530000,   starforceDelta: 1,  levelDelta: 0 },
  "2026-7-11": { combatPowerDelta: 0,        starforceDelta: 0,  levelDelta: 2 },
  "2026-7-12": { combatPowerDelta: 180000,   starforceDelta: 0,  levelDelta: 1 },
  "2026-7-13": { combatPowerDelta: 2_100_000, starforceDelta: 2,  levelDelta: 0, note: "큐브 작업" },
  "2026-7-14": { combatPowerDelta: 440000,   starforceDelta: 1,  levelDelta: 1 },
  "2026-7-15": { combatPowerDelta: 90000,    starforceDelta: 0,  levelDelta: 1 },
  "2026-7-16": { combatPowerDelta: 320000,   starforceDelta: 0,  levelDelta: 0 },
  "2026-7-17": { combatPowerDelta: 760000,   starforceDelta: 1,  levelDelta: 1 },
  "2026-7-18": { combatPowerDelta: -18000,   starforceDelta: 0,  levelDelta: 0 },
  "2026-7-19": { combatPowerDelta: 145000,   starforceDelta: 0,  levelDelta: 1 },
  "2026-7-20": { combatPowerDelta: 980000,   starforceDelta: 1,  levelDelta: 0 },
  "2026-7-21": { combatPowerDelta: 0,        starforceDelta: 0,  levelDelta: 1 },
  "2026-7-22": { combatPowerDelta: 560000,   starforceDelta: 0,  levelDelta: 0 },
  "2026-7-23": { combatPowerDelta: 3_400_000, starforceDelta: 2,  levelDelta: 1, note: "무기 강화 성공!" },
  "2026-7-24": { combatPowerDelta: 210000,   starforceDelta: 0,  levelDelta: 1 },
  "2026-7-25": { combatPowerDelta: 88000,    starforceDelta: 0,  levelDelta: 0 },
  "2026-7-26": { combatPowerDelta: 430000,   starforceDelta: 1,  levelDelta: 1 },
  "2026-7-27": { combatPowerDelta: 190000,   starforceDelta: 0,  levelDelta: 0 },
  "2026-7-28": { combatPowerDelta: 670000,   starforceDelta: 0,  levelDelta: 1 },
  "2026-7-29": { combatPowerDelta: 145000,   starforceDelta: 0,  levelDelta: 1 },
  "2026-7-30": { combatPowerDelta: 2_800_000, starforceDelta: 1,  levelDelta: 0, note: "큐브 대박" },
  "2026-7-31": { combatPowerDelta: 320000,   starforceDelta: 0,  levelDelta: 1 },
};

// Weekly report summaries (every Thursday — July 2026 Thursdays: 2,9,16,23,30)
const WEEKLY_REPORTS: Record<string, { totalDelta: number; highlight: string }> = {
  "2026-7-3":  { totalDelta: 504000,    highlight: "스타포스 +1 달성" },
  "2026-7-10": { totalDelta: 2_938_000, highlight: "총 레벨 +5, 스타포스 평균 +1" },
  "2026-7-17": { totalDelta: 3_195_000, highlight: "큐브 작업으로 큰 상승" },
  "2026-7-24": { totalDelta: 4_958_000, highlight: "무기 강화 성공! 역대 최고 주간 상승" },
  "2026-7-31": { totalDelta: 4_558_000, highlight: "꾸준한 일퀘 + 큐브 효과" },
};

// Monthly report (every 1st)
const MONTHLY_REPORTS: Record<string, { totalDelta: number; highlight: string; levelGain: number }> = {
  "2026-7-1": { totalDelta: 16_114_000, highlight: "6월 총 전투력 상승량", levelGain: 8 },
};

// ─── Helpers ────────────────────────────────────────────────────────────────

const POTENTIAL_STYLE: Record<string, { border: string; bg: string; text: string; badge: string }> = {
  "레전드리": { border: "#f59e0b", bg: "rgba(245,158,11,0.08)", text: "#f59e0b", badge: "text-amber-400 bg-amber-400/10 border-amber-400/30" },
  "유니크": { border: "#a78bfa", bg: "rgba(167,139,250,0.08)", text: "#a78bfa", badge: "text-violet-400 bg-violet-400/10 border-violet-400/30" },
  "에픽": { border: "#60a5fa", bg: "rgba(96,165,250,0.08)", text: "#60a5fa", badge: "text-sky-400 bg-sky-400/10 border-sky-400/30" },
  "레어": { border: "#4ade80", bg: "rgba(74,222,128,0.08)", text: "#4ade80", badge: "text-emerald-400 bg-emerald-400/10 border-emerald-400/30" },
};

function getPotStyle(grade: string) {
  return POTENTIAL_STYLE[grade] ?? { border: "#7880a4", bg: "rgba(120,128,164,0.08)", text: "#7880a4", badge: "text-muted-foreground border-border" };
}

function StarRow({ count, max = 25 }: { count: number; max?: number }) {
  return (
    <div className="flex gap-px flex-wrap">
      {Array.from({ length: max }).map((_, i) => (
        <Star key={i} size={6} className={i < count ? "fill-amber-400 text-amber-400" : "text-white/10"} />
      ))}
    </div>
  );
}

function PotBadge({ grade }: { grade: string }) {
  const s = getPotStyle(grade);
  return (
    <span className={`text-[9px] px-1.5 py-0.5 rounded border font-mono ${s.badge}`}>{grade}</span>
  );
}

// ─── Equipment Grid ──────────────────────────────────────────────────────────

function EquipmentView({ char }: { char: typeof CHARACTERS[0] }) {
  const [selected, setSelected] = useState<string | null>(null);

  const selectedItem = selected ? EQUIPMENT_DATA[selected] : null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Rajdhani', sans-serif" }}>
          {char.name} 장비창
        </h2>
        <span className="text-xs text-muted-foreground font-mono">평균 스타포스 {char.starforce}성</span>
      </div>

      <div className="flex gap-6 items-start">
        {/* Grid */}
        <div
          className="grid gap-1.5 shrink-0"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(5, 64px)",
            gridAutoRows: "64px",
          }}
        >
          {Array.from({ length: 7 }).flatMap((_, rowIdx) =>
            Array.from({ length: 5 }).map((_, colIdx) => {
              const row = rowIdx + 1;
              const col = colIdx + 1;
              const slotDef = EQUIP_SLOTS.find(s => s.row === row && s.col === col);
              const slotName = slotDef?.slot ?? null;
              const item = slotName ? EQUIPMENT_DATA[slotName] : null;

              if (!slotDef) {
                return <div key={`${row}-${col}`} />;
              }

              if (!item) {
                return (
                  <div
                    key={`${row}-${col}`}
                    className="w-16 h-16 rounded-lg border border-dashed border-white/10 flex items-center justify-center"
                  >
                    <span className="text-[9px] text-muted-foreground/40 text-center leading-tight px-1">{slotName}</span>
                  </div>
                );
              }

              const potStyle = getPotStyle(item.potential);
              const isSelected = selected === slotName;

              return (
                <button
                  key={`${row}-${col}`}
                  onClick={() => setSelected(isSelected ? null : slotName)}
                  className="w-16 h-16 rounded-lg relative flex flex-col items-center justify-center transition-all hover:scale-105 active:scale-95 group"
                  style={{
                    border: `1.5px solid ${isSelected ? potStyle.border : potStyle.border + "80"}`,
                    backgroundColor: isSelected ? potStyle.bg : "rgba(20,23,40,0.9)",
                    boxShadow: isSelected ? `0 0 12px ${potStyle.border}40` : undefined,
                  }}
                  title={item.name}
                >
                  {/* Star count */}
                  {item.stars > 0 && (
                    <div className="absolute top-1 left-1 flex items-center gap-0.5">
                      <Star size={7} className="fill-amber-400 text-amber-400" />
                      <span className="text-[8px] font-mono text-amber-400">{item.stars}</span>
                    </div>
                  )}
                  {/* Enhancement */}
                  {item.enhancement && (
                    <div className="absolute top-1 right-1">
                      <span className="text-[8px] font-mono text-emerald-400">{item.enhancement}</span>
                    </div>
                  )}
                  {/* Icon placeholder */}
                  <Package
                    size={22}
                    style={{ color: potStyle.text }}
                    className="group-hover:scale-110 transition-transform"
                  />
                  <span className="text-[8px] text-muted-foreground mt-0.5 leading-none">{slotName}</span>
                </button>
              );
            })
          )}
        </div>

        {/* Detail panel */}
        {selectedItem ? (
          <div className="flex-1 bg-card border rounded-2xl overflow-hidden" style={{ borderColor: getPotStyle(selectedItem.potential).border + "60" }}>
            {/* Header */}
            <div className="p-4 border-b border-border flex items-start justify-between gap-3" style={{ backgroundColor: getPotStyle(selectedItem.potential).bg }}>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <PotBadge grade={selectedItem.potential} />
                  {selectedItem.enhancement && (
                    <span className="text-xs font-mono text-emerald-400">{selectedItem.enhancement}</span>
                  )}
                </div>
                <p className="font-bold text-foreground" style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.05rem" }}>
                  {selectedItem.name}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">{selected}</p>
              </div>
              <button
                onClick={() => setSelected(null)}
                className="w-7 h-7 rounded-lg bg-secondary/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors shrink-0"
              >
                <X size={14} />
              </button>
            </div>

            {/* Star force */}
            {selectedItem.stars > 0 && (
              <div className="px-4 py-3 border-b border-border">
                <div className="flex items-center gap-2 mb-2">
                  <Star size={12} className="fill-amber-400 text-amber-400" />
                  <span className="text-xs font-mono text-amber-400">{selectedItem.stars}성</span>
                </div>
                <StarRow count={selectedItem.stars} />
              </div>
            )}

            {/* Stats */}
            <div className="p-4 space-y-1">
              <p className="text-xs text-muted-foreground mb-2 font-medium">옵션</p>
              {selectedItem.description.split("\n").map((line, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-primary shrink-0" />
                  <span className="text-sm text-foreground">{line}</span>
                </div>
              ))}
            </div>

            {/* Main stat highlight */}
            <div className="mx-4 mb-4 p-3 rounded-xl bg-secondary/50 border border-border">
              <p className="text-[10px] text-muted-foreground mb-1">주요 스탯</p>
              <p className="text-base font-bold font-mono" style={{ color: getPotStyle(selectedItem.potential).text }}>
                {selectedItem.mainStat}
              </p>
              {selectedItem.attackPower > 0 && (
                <p className="text-xs text-muted-foreground font-mono mt-0.5">공격력 +{selectedItem.attackPower.toLocaleString()}</p>
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 bg-card border border-dashed border-border rounded-2xl flex flex-col items-center justify-center gap-3 min-h-48">
            <Package size={32} className="text-muted-foreground/30" />
            <p className="text-sm text-muted-foreground">장비 슬롯을 클릭하면<br />상세 정보가 표시됩니다</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Character View ──────────────────────────────────────────────────────────

function CharacterView({ char }: { char: typeof CHARACTERS[0] }) {
  const abilityColors: Record<string, string> = {
    "레전드리": "bg-amber-500",
    "유니크": "bg-violet-500",
    "에픽": "bg-sky-500",
    "레어": "bg-emerald-500",
  };

  return (
    <div className="space-y-5">
      {/* Top two-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">

        {/* Left column */}
        <div className="lg:col-span-2 space-y-4">
          {/* 전투력 */}
          <div className="bg-card border border-border rounded-xl p-5 text-center">
            <p className="text-xs text-muted-foreground mb-1">현재 전투력</p>
            <p className="text-3xl font-bold font-mono" style={{ color: "#ff8c42", fontFamily: "'Rajdhani', sans-serif" }}>
              {char.combatPower.toLocaleString()}
            </p>
          </div>

          {/* 하이퍼 스탯 */}
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-xs font-semibold text-foreground mb-3 flex items-center gap-2">
              <ChevronUp size={13} className="text-primary" /> 하이퍼 스탯
            </p>
            <div className="space-y-1.5">
              {char.hyperStats.map(hs => (
                <div key={hs.name} className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{hs.name}</span>
                  <span className={`font-mono ${hs.level > 0 ? "text-primary" : "text-muted-foreground/40"}`}>
                    {hs.level > 0 ? `Lv.${hs.level}` : "-"}
                  </span>
                </div>
              ))}
            </div>
            {/* Preset tabs */}
            <div className="flex gap-1 mt-3 pt-3 border-t border-border">
              <span className="text-[10px] text-muted-foreground mr-1">프리셋</span>
              {[1, 2, 3].map(n => (
                <button key={n} className={`w-7 h-6 rounded text-[10px] font-mono transition-colors ${n === 1 ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                  {n}
                </button>
              ))}
            </div>
          </div>

          {/* 어빌리티 */}
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-xs font-semibold text-foreground mb-1">어빌리티</p>
            <p className="text-[10px] text-muted-foreground mb-3">보유 명성치: 38,294</p>
            <div className="space-y-1.5">
              {char.abilities.map((ab, i) => (
                <div
                  key={i}
                  className={`text-xs px-3 py-2 rounded-lg text-white font-medium ${abilityColors[ab.grade] ?? "bg-secondary"}`}
                >
                  {ab.text}
                </div>
              ))}
            </div>
            <div className="flex gap-1 mt-3 pt-3 border-t border-border">
              <span className="text-[10px] text-muted-foreground mr-1">프리셋</span>
              {[1, 2, 3].map(n => (
                <button key={n} className={`w-7 h-6 rounded text-[10px] font-mono transition-colors ${n === 1 ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                  {n}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right column */}
        <div className="lg:col-span-3 space-y-4">
          {/* 스탯 정보 */}
          <div className="bg-card border border-border rounded-xl p-5">
            <p className="text-xs font-semibold text-foreground mb-3 text-center">스탯 정보</p>
            <div className="grid grid-cols-2 gap-x-8 gap-y-1.5 text-xs">
              {[
                { label: "STR", value: char.stats.STR.toLocaleString() },
                { label: "HP", value: char.hp.toLocaleString() },
                { label: "DEX", value: char.stats.DEX.toLocaleString() },
                { label: "MP", value: char.mp.toLocaleString() },
                { label: "INT", value: char.stats.INT.toLocaleString() },
                { label: "", value: "" },
                { label: "LUK", value: char.stats.LUK.toLocaleString() },
                { label: "", value: "" },
              ].map((row, i) => (
                <div key={i} className="flex items-center justify-between border-b border-border/40 pb-1">
                  <span className="text-muted-foreground font-mono">{row.label}</span>
                  <span className="text-foreground font-mono font-medium">{row.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 상세 정보 */}
          <div className="bg-card border border-border rounded-xl p-5">
            <p className="text-xs font-semibold text-foreground mb-3 text-center">상세 정보</p>
            <div className="space-y-1">
              {char.detailStats.map((row, i) => (
                <div key={i} className="grid grid-cols-2 gap-4 text-xs border-b border-border/30 pb-1.5">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{row.label}</span>
                    <span className="text-foreground font-mono">{row.value}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{row.label2}</span>
                    <span className="text-foreground font-mono">{row.value2}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 장착 심볼 — 우측 컬럼 빈 공간 */}
          {(char.arcaneSymbols.length > 0 || char.sacredSymbols.length > 0) && (
            <div className="bg-card border border-border rounded-xl p-5">
              <p className="text-sm font-bold text-foreground mb-4" style={{ fontFamily: "'Rajdhani', sans-serif" }}>
                장착 심볼
              </p>

              {/* 아케인심볼 row */}
              {/* 아케인심볼 */}
              {char.arcaneSymbols.length > 0 && (
                <div className="flex flex-wrap gap-3 mb-3">
                  {char.arcaneSymbols.map((sym, i) => {
                    const arcaneGradients = [
                      "from-sky-500 to-cyan-400",
                      "from-pink-500 to-fuchsia-400",
                      "from-violet-500 to-purple-400",
                      "from-teal-500 to-emerald-400",
                      "from-red-500 to-rose-400",
                      "from-blue-500 to-indigo-400",
                    ];
                    const grad = arcaneGradients[i % arcaneGradients.length];
                    return (
                      <div key={sym.name} className="flex flex-col items-center gap-1.5">
                        <div className={`w-14 h-14 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center shadow-lg ring-2 ring-white/10`}>
                          <span className="text-white text-[10px] font-bold leading-tight text-center px-1">
                            {sym.name.slice(0, 2)}
                          </span>
                        </div>
                        <span className="text-xs font-semibold font-mono text-foreground">Lv.{sym.level}</span>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* 성스러운심볼 */}
              {char.sacredSymbols.length > 0 && (
                <div className="flex flex-wrap gap-3">
                  {char.sacredSymbols.map((sym, i) => {
                    const sacredGradients = [
                      "from-amber-400 to-yellow-300",
                      "from-orange-500 to-amber-400",
                      "from-lime-500 to-green-400",
                      "from-cyan-500 to-sky-400",
                      "from-rose-500 to-pink-400",
                      "from-purple-500 to-violet-400",
                    ];
                    const grad = sacredGradients[i % sacredGradients.length];
                    return (
                      <div key={sym.name} className="flex flex-col items-center gap-1.5">
                        <div className={`w-14 h-14 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center shadow-lg ring-2 ring-white/10`}>
                          <span className="text-white text-[10px] font-bold leading-tight text-center px-1">
                            {sym.name.slice(0, 2)}
                          </span>
                        </div>
                        <span className="text-xs font-semibold font-mono text-foreground">Lv.{sym.level}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Dashboard ───────────────────────────────────────────────────────────────

function StatBar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <span className="text-xs text-muted-foreground font-mono">{label}</span>
        <span className="text-xs font-mono" style={{ color }}>{value.toLocaleString()}</span>
      </div>
      <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: color }} />
      </div>
    </div>
  );
}

// ─── Character Select Page ───────────────────────────────────────────────────

type Character = typeof CHARACTERS[0];
type GroupBy = "직업별" | "태그별" | "주스탯별";

function CharacterCard({
  char,
  isSelected,
  tags,
  onSelect,
  onTagToggle,
}: {
  char: Character;
  isSelected: boolean;
  tags: TagName[];
  onSelect: () => void;
  onTagToggle: (tag: TagName) => void;
}) {
  const [showTagPicker, setShowTagPicker] = useState(false);
  const available = ALL_TAGS.filter(t => !tags.includes(t));

  return (
    <div
      onClick={onSelect}
      className={`relative rounded-xl border transition-all cursor-pointer group ${
        isSelected
          ? "border-primary/60 bg-primary/10 shadow-lg shadow-primary/10"
          : "border-border hover:border-primary/30 bg-card"
      }`}
    >
      {isSelected && (
        <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-primary flex items-center justify-center z-10">
          <CheckCircle2 size={11} className="text-primary-foreground" />
        </div>
      )}
      <div className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-11 h-11 rounded-full overflow-hidden bg-secondary shrink-0 ring-2 transition-all ${isSelected ? "ring-primary/60" : "ring-transparent"}`}>
            <img src={char.image} alt={char.name} className="w-full h-full object-cover" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-bold text-foreground truncate text-sm" style={{ fontFamily: "'Rajdhani', sans-serif" }}>
              {char.name}
            </p>
            <p className="text-[11px] text-muted-foreground">{char.jobDetail}</p>
            <p className="text-[10px] font-mono text-muted-foreground">Lv.{char.level} · {char.world}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-1.5 mb-3 text-[10px] font-mono">
          <div className="bg-background/60 rounded-lg px-2 py-1.5">
            <p className="text-muted-foreground mb-0.5">전투력</p>
            <p className="text-primary font-semibold">{(char.combatPower / 10000).toFixed(0)}만</p>
          </div>
          <div className="bg-background/60 rounded-lg px-2 py-1.5">
            <p className="text-muted-foreground mb-0.5">주스탯</p>
            <p className="text-foreground font-semibold">{char.mainStat} · {char.jobClass}</p>
          </div>
        </div>

        {/* Tags */}
        <div className="flex items-center gap-1 flex-wrap" onClick={e => e.stopPropagation()}>
          {tags.map(tag => (
            <button
              key={tag}
              onClick={() => onTagToggle(tag)}
              className={`text-[9px] px-1.5 py-0.5 rounded border transition-all hover:opacity-60 ${TAG_COLOR[tag]}`}
              title="클릭해서 제거"
            >
              {tag}
            </button>
          ))}
          <div className="relative">
            <button
              onClick={() => setShowTagPicker(v => !v)}
              className="text-[9px] px-1.5 py-0.5 rounded border border-dashed border-border text-muted-foreground hover:text-foreground hover:border-primary/40 transition-all flex items-center gap-0.5"
            >
              <Plus size={7} /> 태그
            </button>
            {showTagPicker && available.length > 0 && (
              <div className="absolute bottom-full left-0 mb-1.5 bg-card border border-border rounded-xl p-2 flex flex-wrap gap-1 w-40 z-20 shadow-2xl">
                {available.map(t => (
                  <button
                    key={t}
                    onClick={() => { onTagToggle(t); setShowTagPicker(false); }}
                    className={`text-[9px] px-1.5 py-0.5 rounded border transition-all hover:opacity-80 ${TAG_COLOR[t]}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function CharacterSelectView({
  characters,
  selected,
  onSelect,
  charTags,
  onTagToggle,
}: {
  characters: Character[];
  selected: Character;
  onSelect: (c: Character) => void;
  charTags: Record<number, TagName[]>;
  onTagToggle: (id: number, tag: TagName) => void;
}) {
  const [groupBy, setGroupBy] = useState<GroupBy>("직업별");

  const getTags = (c: Character) => charTags[c.id] ?? c.tags;

  const groups: { label: string; chars: Character[] }[] = (() => {
    if (groupBy === "직업별") {
      return JOB_CLASSES.filter(j => j !== "전체")
        .map(cls => ({ label: cls, chars: characters.filter(c => c.jobClass === cls) }))
        .filter(g => g.chars.length > 0);
    }
    if (groupBy === "주스탯별") {
      return MAIN_STATS.filter(s => s !== "전체")
        .map(stat => ({ label: stat, chars: characters.filter(c => c.mainStat === stat) }))
        .filter(g => g.chars.length > 0);
    }
    // 태그별 - character can appear in multiple groups
    const tagGroups = ALL_TAGS.map(tag => ({
      label: tag,
      chars: characters.filter(c => getTags(c).includes(tag)),
    })).filter(g => g.chars.length > 0);
    const untagged = characters.filter(c => getTags(c).length === 0);
    return [
      ...tagGroups,
      ...(untagged.length > 0 ? [{ label: "태그 없음", chars: untagged }] : []),
    ];
  })();

  return (
    <div className="space-y-6">
      {/* Header row */}
      <div className="flex items-center gap-4 flex-wrap">
        <div>
          <p className="text-xs text-muted-foreground">{characters.length}개 캐릭터</p>
        </div>
        <div className="ml-auto flex items-center gap-1 bg-secondary/60 p-1 rounded-xl border border-border">
          {(["직업별", "태그별", "주스탯별"] as GroupBy[]).map(g => (
            <button
              key={g}
              onClick={() => setGroupBy(g)}
              className={`text-xs px-3 py-1.5 rounded-lg transition-all ${
                groupBy === g
                  ? "bg-card text-foreground font-medium shadow-sm border border-border"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>

      {/* Groups */}
      {groups.map(group => (
        <div key={group.label}>
          <div className="flex items-center gap-3 mb-3">
            <h3 className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Rajdhani', sans-serif" }}>
              {group.label}
            </h3>
            <span className="text-[10px] text-muted-foreground font-mono">{group.chars.length}개</span>
            <div className="flex-1 h-px bg-border" />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {group.chars
              .sort((a, b) => b.combatPower - a.combatPower)
              .map(char => (
                <CharacterCard
                  key={`${group.label}-${char.id}`}
                  char={char}
                  isSelected={char.id === selected.id}
                  tags={getTags(char)}
                  onSelect={() => onSelect(char)}
                  onTagToggle={tag => onTagToggle(char.id, tag)}
                />
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function Dashboard({ char }: { char: typeof CHARACTERS[0] }) {
  const doneCount = BOSSES.filter(b => b.done).length;
  const contentDone = CONTENT.filter(c => c.done).length;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "전투력", value: char.combatPower.toLocaleString(), icon: Zap, color: "#ff8c42" },
          { label: "아케인포스", value: char.arcaneForce, icon: Star, color: "#7dd3fc" },
          { label: "성스러운포스", value: char.sacredForce, icon: Award, color: "#c084fc" },
          { label: "스타포스", value: `${char.starforce}성`, icon: Star, color: "#fbbf24" },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${color}18` }}>
              <Icon size={18} style={{ color }} />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="font-semibold text-foreground font-mono text-sm">{value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Shield size={14} className="text-primary" /> 기본 스탯
          </h3>
          <StatBar label="STR" value={char.stats.STR} max={60000} color="#f87171" />
          <StatBar label="DEX" value={char.stats.DEX} max={60000} color="#fb923c" />
          <StatBar label="INT" value={char.stats.INT} max={60000} color="#60a5fa" />
          <StatBar label="LUK" value={char.stats.LUK} max={60000} color="#a78bfa" />
          <div className="pt-2 border-t border-border space-y-3">
            <StatBar label="HP" value={char.hp} max={200000} color="#4ade80" />
            <StatBar label="MP" value={char.mp} max={80000} color="#38bdf8" />
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
            <Target size={14} className="text-primary" /> 보스 현황
            <span className="ml-auto text-xs text-muted-foreground font-mono">{doneCount}/{BOSSES.length}</span>
          </h3>
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1" style={{ scrollbarWidth: "none" }}>
            {BOSSES.map(boss => (
              <div key={boss.name} className="flex items-center gap-2">
                {boss.done
                  ? <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                  : <XCircle size={14} className="text-muted-foreground/40 shrink-0" />}
                <span className={`text-xs flex-1 ${boss.done ? "text-muted-foreground line-through" : "text-foreground"}`}>{boss.name}</span>
                <span className="text-[10px] text-muted-foreground font-mono">{boss.difficulty}</span>
                <span className={`text-[10px] px-1 rounded font-mono ${boss.resetType === "주간" ? "text-violet-400 bg-violet-400/10" : "text-sky-400 bg-sky-400/10"}`}>{boss.resetType}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
            <Map size={14} className="text-primary" /> 일일/주간 콘텐츠
            <span className="ml-auto text-xs text-muted-foreground font-mono">{contentDone}/{CONTENT.length}</span>
          </h3>
          <div className="space-y-2">
            {CONTENT.map(c => (
              <div key={c.name} className="flex items-start gap-2">
                {c.done
                  ? <CheckCircle2 size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                  : <XCircle size={14} className="text-muted-foreground/40 shrink-0 mt-0.5" />}
                <div className="flex-1 min-w-0">
                  <p className={`text-xs truncate ${c.done ? "text-muted-foreground line-through" : "text-foreground"}`}>{c.name}</p>
                  <p className="text-[10px] text-muted-foreground">{c.reward}</p>
                </div>
                <span className={`text-[10px] px-1 rounded font-mono shrink-0 ${c.type === "일일" ? "text-sky-400 bg-sky-400/10" : "text-violet-400 bg-violet-400/10"}`}>{c.type}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Boss / Content Views ────────────────────────────────────────────────────

function BossView() {
  const weekly = BOSSES.filter(b => b.resetType === "주간");
  const daily = BOSSES.filter(b => b.resetType === "일간");
  return (
    <div className="space-y-6">
      {[{ label: "주간 보스", list: weekly, color: "text-violet-400", iconColor: "text-violet-400" },
        { label: "일간 보스", list: daily, color: "text-sky-400", iconColor: "text-sky-400" }].map(({ label, list, color }) => (
        <div key={label}>
          <h3 className={`text-sm font-semibold text-foreground mb-3 flex items-center gap-2`}>
            <Clock size={14} className={color} /> {label}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {list.map(boss => (
              <div key={boss.name} className={`bg-card border rounded-xl p-4 flex items-center gap-3 transition-all ${boss.done ? "opacity-50 border-border" : "border-border hover:border-primary/30"}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${boss.done ? "bg-emerald-400/10" : "bg-secondary"}`}>
                  {boss.done ? <CheckCircle2 size={18} className="text-emerald-400" /> : <Target size={18} className="text-primary" />}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-medium ${boss.done ? "line-through text-muted-foreground" : "text-foreground"}`}>{boss.name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] text-muted-foreground font-mono">권장 {boss.recommended} 레벨</span>
                    <span className={`text-[10px] px-1.5 rounded font-mono ${color} bg-current/10`}>{boss.difficulty}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function ContentView() {
  return (
    <div className="space-y-6">
      {["일일", "주간"].map(type => (
        <div key={type}>
          <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
            <Calendar size={14} className={type === "일일" ? "text-sky-400" : "text-violet-400"} />
            {type} 콘텐츠
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {CONTENT.filter(c => c.type === type).map(c => (
              <div key={c.name} className={`bg-card border rounded-xl p-4 flex items-center gap-3 transition-all ${c.done ? "opacity-50 border-border" : "border-border hover:border-primary/30"}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${c.done ? "bg-emerald-400/10" : "bg-secondary"}`}>
                  {c.done ? <CheckCircle2 size={18} className="text-emerald-400" /> : <Map size={18} className="text-primary" />}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-medium ${c.done ? "line-through text-muted-foreground" : "text-foreground"}`}>{c.name}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{c.reward}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── App ─────────────────────────────────────────────────────────────────────

// ─── Report View ─────────────────────────────────────────────────────────────

const WEEK_LABELS = ["일", "월", "화", "수", "목", "금", "토"];
const MONTH_NAMES = ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];

function formatDelta(n: number) {
  if (n === 0) return null;
  const abs = Math.abs(n);
  const sign = n > 0 ? "+" : "-";
  if (abs >= 10000) return `${sign}${(abs / 10000).toFixed(0)}만`;
  return `${sign}${abs.toLocaleString()}`;
}

function ReportView() {
  const today = new Date(2026, 6, 8); // fixed "today" for demo
  const [viewDate, setViewDate] = useState(new Date(2026, 6, 1));
  const [selectedDay, setSelectedDay] = useState<number | null>(8);

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDow = new Date(year, month, 1).getDay(); // 0=Sun
  const startOffset = firstDow; // Sun=0

  const prevMonth = () => setViewDate(new Date(year, month - 1, 1));
  const nextMonth = () => setViewDate(new Date(year, month + 1, 1));

  const isToday = (d: number) => year === today.getFullYear() && month === today.getMonth() && d === today.getDate();
  const isFuture = (d: number) => new Date(year, month, d) > today;
  const isThursday = (d: number) => new Date(year, month, d).getDay() === 4;
  const isFirstOfMonth = (d: number) => d === 1;
  const reportKey = (d: number) => `${year}-${month + 1}-${d}`;

  const selectedKey = selectedDay != null ? reportKey(selectedDay) : null;
  const selectedReport = selectedKey ? REPORT_DATA[selectedKey] : null;
  const selectedWeekly = selectedKey ? WEEKLY_REPORTS[selectedKey] : null;
  const selectedMonthly = selectedKey ? MONTHLY_REPORTS[selectedKey] : null;
  const selectedIsThursday = selectedDay != null && isThursday(selectedDay);
  const selectedIsFirst = selectedDay != null && isFirstOfMonth(selectedDay);

  // Monthly totals for current view
  const monthlyTotal = Object.entries(REPORT_DATA)
    .filter(([k]) => k.startsWith(`${year}-${month + 1}-`))
    .reduce((sum, [, v]) => sum + v.combatPowerDelta, 0);

  const cells: (number | null)[] = [
    ...Array(startOffset).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  return (
    <div className="flex gap-6 h-full min-h-0">
      {/* Calendar panel */}
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        {/* Month nav + summary */}
        <div className="flex items-center gap-4">
          <button onClick={prevMonth} className="w-8 h-8 rounded-lg bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-primary/30 transition-all">
            <ChevronLeft size={15} />
          </button>
          <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Rajdhani', sans-serif" }}>
            {year}년 {MONTH_NAMES[month]}
          </h2>
          <button onClick={nextMonth} className="w-8 h-8 rounded-lg bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-primary/30 transition-all">
            <ChevronRight size={15} />
          </button>
          {/* Monthly total */}
          <div className="ml-auto flex items-center gap-2 bg-card border border-border rounded-xl px-4 py-2">
            <TrendingUp size={13} className="text-emerald-400" />
            <span className="text-xs text-muted-foreground">이달 총 상승</span>
            <span className="text-sm font-bold font-mono text-emerald-400">{formatDelta(monthlyTotal) ?? "0"}</span>
          </div>
        </div>

        {/* Week header */}
        <div className="grid grid-cols-7 gap-1">
          {WEEK_LABELS.map((d, i) => (
            <div key={d} className={`text-center text-xs font-medium py-1.5 ${i === 0 ? "text-red-400" : i === 6 ? "text-sky-400" : "text-muted-foreground"}`}>
              {d}
            </div>
          ))}
        </div>

        {/* Day grid */}
        <div className="grid grid-cols-7 gap-1 flex-1">
          {cells.map((day, idx) => {
            if (day === null) return <div key={`empty-${idx}`} />;

            const key = reportKey(day);
            const report = REPORT_DATA[key];
            const future = isFuture(day);
            const thu = isThursday(day);
            const first = isFirstOfMonth(day);
            const active = selectedDay === day;
            const delta = report?.combatPowerDelta ?? 0;
            const dow = new Date(year, month, day).getDay(); // 0=Sun

            return (
              <button
                key={day}
                onClick={() => setSelectedDay(day === selectedDay ? null : day)}
                disabled={future}
                className={`relative rounded-xl border p-2 flex flex-col items-start transition-all text-left min-h-[72px] ${
                  future
                    ? "border-border/30 opacity-30 cursor-default"
                    : active
                    ? "border-primary/60 bg-primary/10 shadow-sm shadow-primary/10"
                    : "border-border bg-card hover:border-primary/30 hover:bg-card/80"
                }`}
              >
                {/* Day number */}
                <div className="flex items-center gap-1 w-full mb-1">
                  <span className={`text-xs font-semibold font-mono ${
                    isToday(day) ? "text-primary" :
                    dow === 0 ? "text-red-400/80" :
                    dow === 6 ? "text-sky-400" :
                    "text-foreground"
                  }`}>
                    {day}
                  </span>
                  {isToday(day) && (
                    <span className="text-[8px] px-1 rounded bg-primary text-primary-foreground font-bold ml-auto">오늘</span>
                  )}
                </div>

                {/* Delta */}
                {report && delta !== 0 && (
                  <div className={`flex items-center gap-0.5 text-[9px] font-mono font-semibold ${delta > 0 ? "text-emerald-400" : "text-red-400"}`}>
                    {delta > 0 ? <TrendingUp size={8} /> : <TrendingDown size={8} />}
                    {formatDelta(delta)}
                  </div>
                )}
                {report && delta === 0 && !future && (
                  <div className="flex items-center gap-0.5 text-[9px] font-mono text-muted-foreground/50">
                    <Minus size={8} /> 변화없음
                  </div>
                )}

                {/* Badges */}
                <div className="flex gap-0.5 mt-auto flex-wrap">
                  {first && (
                    <span className="text-[7px] px-1 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold">월간</span>
                  )}
                  {thu && (
                    <span className="text-[7px] px-1 py-0.5 rounded bg-violet-500/20 text-violet-400 border border-violet-500/30 font-bold">주간</span>
                  )}
                  {report?.note && (
                    <span className="text-[7px] px-1 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">메모</span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Detail panel */}
      <div className="w-72 shrink-0 flex flex-col gap-3">
        {selectedDay && selectedReport ? (
          <>
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-foreground" style={{ fontFamily: "'Rajdhani', sans-serif" }}>
                  {month + 1}월 {selectedDay}일 리포트
                </h3>
                <button onClick={() => setSelectedDay(null)} className="text-muted-foreground hover:text-foreground transition-colors">
                  <X size={14} />
                </button>
              </div>

              {/* Daily stats */}
              <div className="space-y-3">
                <div className="flex items-center justify-between py-2 border-b border-border">
                  <span className="text-xs text-muted-foreground">전투력 변화</span>
                  <div className={`flex items-center gap-1 text-sm font-bold font-mono ${selectedReport.combatPowerDelta > 0 ? "text-emerald-400" : selectedReport.combatPowerDelta < 0 ? "text-red-400" : "text-muted-foreground"}`}>
                    {selectedReport.combatPowerDelta > 0 ? <TrendingUp size={14} /> : selectedReport.combatPowerDelta < 0 ? <TrendingDown size={14} /> : <Minus size={14} />}
                    {formatDelta(selectedReport.combatPowerDelta) ?? "변화없음"}
                  </div>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-border">
                  <span className="text-xs text-muted-foreground">스타포스 변화</span>
                  <span className={`text-sm font-bold font-mono ${selectedReport.starforceDelta > 0 ? "text-amber-400" : selectedReport.starforceDelta < 0 ? "text-red-400" : "text-muted-foreground"}`}>
                    {selectedReport.starforceDelta > 0 ? `+${selectedReport.starforceDelta}성` : selectedReport.starforceDelta < 0 ? `${selectedReport.starforceDelta}성` : "-"}
                  </span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-border">
                  <span className="text-xs text-muted-foreground">레벨업</span>
                  <span className={`text-sm font-bold font-mono ${selectedReport.levelDelta > 0 ? "text-sky-400" : "text-muted-foreground"}`}>
                    {selectedReport.levelDelta > 0 ? `+${selectedReport.levelDelta} 레벨` : "-"}
                  </span>
                </div>
                {selectedReport.note && (
                  <div className="pt-1">
                    <p className="text-[10px] text-muted-foreground mb-1">메모</p>
                    <p className="text-xs text-foreground bg-secondary/50 rounded-lg px-3 py-2">{selectedReport.note}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Weekly report */}
            {selectedIsThursday && selectedWeekly && (
              <div className="bg-card border border-violet-500/30 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-6 h-6 rounded-lg bg-violet-500/20 flex items-center justify-center">
                    <BarChart2 size={12} className="text-violet-400" />
                  </div>
                  <h4 className="text-sm font-bold text-violet-400" style={{ fontFamily: "'Rajdhani', sans-serif" }}>주간 리포트</h4>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">주간 총 전투력 상승</span>
                    <span className="text-sm font-bold font-mono text-violet-400">+{(selectedWeekly.totalDelta / 10000).toFixed(0)}만</span>
                  </div>
                  <p className="text-xs text-foreground bg-violet-500/10 rounded-lg px-3 py-2 border border-violet-500/20">
                    {selectedWeekly.highlight}
                  </p>
                </div>
              </div>
            )}

            {/* Monthly report */}
            {selectedIsFirst && selectedMonthly && (
              <div className="bg-card border border-amber-500/30 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-6 h-6 rounded-lg bg-amber-500/20 flex items-center justify-center">
                    <Award size={12} className="text-amber-400" />
                  </div>
                  <h4 className="text-sm font-bold text-amber-400" style={{ fontFamily: "'Rajdhani', sans-serif" }}>월간 리포트</h4>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">전월 총 전투력 상승</span>
                    <span className="text-sm font-bold font-mono text-amber-400">+{(selectedMonthly.totalDelta / 10000).toFixed(0)}만</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">레벨 획득</span>
                    <span className="text-sm font-bold font-mono text-amber-400">+{selectedMonthly.levelGain} 레벨</span>
                  </div>
                  <p className="text-xs text-foreground bg-amber-500/10 rounded-lg px-3 py-2 border border-amber-500/20">
                    {selectedMonthly.highlight}
                  </p>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="bg-card border border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-3 h-48">
            <FileText size={28} className="text-muted-foreground/30" />
            <p className="text-sm text-muted-foreground text-center">날짜를 선택하면<br />리포트가 표시됩니다</p>
          </div>
        )}

        {/* Legend */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-xs font-semibold text-muted-foreground mb-3">범례</p>
          <div className="space-y-2">
            {[
              { label: "주간 리포트", color: "bg-violet-500/20 text-violet-400 border-violet-500/30", text: "주간" },
              { label: "월간 리포트", color: "bg-amber-500/20 text-amber-400 border-amber-500/30", text: "월간" },
              { label: "메모 있음", color: "bg-sky-500/10 text-sky-400 border-sky-500/20", text: "메모" },
            ].map(item => (
              <div key={item.label} className="flex items-center gap-2">
                <span className={`text-[8px] px-1.5 py-0.5 rounded border font-bold ${item.color}`}>{item.text}</span>
                <span className="text-xs text-muted-foreground">{item.label}</span>
              </div>
            ))}
            <div className="flex items-center gap-2">
              <TrendingUp size={10} className="text-emerald-400" />
              <span className="text-xs text-muted-foreground">전투력 상승</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingDown size={10} className="text-red-400" />
              <span className="text-xs text-muted-foreground">전투력 하락</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [activeNav, setActiveNav] = useState("dashboard");
  const [selectedChar, setSelectedChar] = useState(CHARACTERS[0]);
  const [charTags, setCharTags] = useState<Record<number, TagName[]>>({});

  const handleTagToggle = (id: number, tag: TagName) => {
    setCharTags(prev => {
      const char = CHARACTERS.find(c => c.id === id)!;
      const current = prev[id] ?? [...char.tags];
      const next = current.includes(tag) ? current.filter(t => t !== tag) : [...current, tag];
      return { ...prev, [id]: next };
    });
  };

  const isCharSelect = activeNav === "charselect";

  const pageTitle: Record<string, string> = {
    dashboard: "대시보드",
    charselect: "캐릭터 선택",
    characters: "캐릭터",
    equipment: "장비",
    boss: "보스",
    content: "콘텐츠",
    report: "리포트",
  };

  return (
    <div className="size-full flex bg-background text-foreground overflow-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Sidebar */}
      <aside className="w-16 md:w-56 flex flex-col bg-card border-r border-border shrink-0">
        {/* Logo */}
        <div className="h-14 flex items-center gap-3 px-4 border-b border-border shrink-0">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: "linear-gradient(135deg, #ff8c42, #f5a623)" }}>
            <Star size={16} className="text-white" fill="white" />
          </div>
          <span className="hidden md:block text-base font-bold text-foreground" style={{ fontFamily: "'Rajdhani', sans-serif", letterSpacing: "0.05em" }}>
            메이플트래커
          </span>
        </div>

        {/* Character selector button + current char */}
        <div className="p-3 border-b border-border space-y-2 shrink-0">
          <button
            onClick={() => setActiveNav("charselect")}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg border transition-all group ${
              isCharSelect
                ? "bg-primary/20 border-primary/50 text-primary"
                : "bg-primary/10 border-primary/30 hover:bg-primary/20 text-primary"
            }`}
          >
            <Users size={14} className="shrink-0" />
            <span className="hidden md:block text-xs font-semibold">캐릭터 선택</span>
            <ChevronRight size={12} className="hidden md:block ml-auto opacity-60 group-hover:translate-x-0.5 transition-transform" />
          </button>

          {/* Current character */}
          <div className="flex items-center gap-2.5 px-1 py-1">
            <div className="w-8 h-8 rounded-full overflow-hidden bg-secondary ring-2 ring-primary/40 shrink-0">
              <img src={selectedChar.image} alt={selectedChar.name} className="w-full h-full object-cover" />
            </div>
            <div className="hidden md:block min-w-0">
              <p className="text-xs font-semibold text-foreground truncate">{selectedChar.name}</p>
              <div className="flex items-center gap-1 mt-0.5">
                <span className="text-[10px] text-muted-foreground font-mono">Lv.{selectedChar.level}</span>
                <span className="text-[10px] text-muted-foreground/40">·</span>
                <span className="text-[10px] text-muted-foreground">{selectedChar.jobClass}</span>
              </div>
              {(charTags[selectedChar.id] ?? selectedChar.tags).length > 0 && (
                <div className="flex gap-1 mt-1 flex-wrap">
                  {(charTags[selectedChar.id] ?? selectedChar.tags).slice(0, 2).map(tag => (
                    <span key={tag} className={`text-[8px] px-1 py-0.5 rounded border ${TAG_COLOR[tag]}`}>{tag}</span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveNav(id)}
              className={`w-full flex items-center gap-3 px-2 py-2.5 rounded-lg transition-all ${activeNav === id ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-secondary"}`}
            >
              <Icon size={16} className="shrink-0" />
              <span className="hidden md:block text-sm">{label}</span>
            </button>
          ))}
        </nav>

        <div className="p-2 border-t border-border shrink-0">
          <button className="w-full flex items-center gap-3 px-2 py-2.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-all">
            <Settings size={16} className="shrink-0" />
            <span className="hidden md:block text-sm">설정</span>
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="h-14 flex items-center gap-4 px-6 border-b border-border shrink-0">
          <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Rajdhani', sans-serif", letterSpacing: "0.03em" }}>
            {pageTitle[activeNav]}
          </h1>
          <div className="ml-auto flex items-center gap-2">
            <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg hover:bg-secondary transition-all border border-border">
              <RefreshCw size={12} />
              <span className="hidden md:inline">동기화</span>
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-all border border-border">
              <Bell size={14} />
            </button>
          </div>
        </header>

        {/* Character banner — hidden on charselect page */}
        {!isCharSelect && (
          <div className="px-6 py-4 border-b border-border bg-card/50 shrink-0">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-12 h-12 rounded-full overflow-hidden ring-2 ring-primary/50 bg-secondary">
                  <img src={selectedChar.image} alt={selectedChar.name} className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground text-[9px] font-bold px-1 rounded font-mono">
                  {selectedChar.level}
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-base font-bold text-foreground" style={{ fontFamily: "'Rajdhani', sans-serif" }}>{selectedChar.name}</h2>
                  <span className="text-xs text-muted-foreground">{selectedChar.jobDetail}</span>
                  <span className="text-xs text-muted-foreground">·</span>
                  <span className="text-xs text-muted-foreground">{selectedChar.world}</span>
                  {selectedChar.guild && (
                    <><span className="text-xs text-muted-foreground">·</span>
                    <span className="text-xs text-primary">〈{selectedChar.guild}〉</span></>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-1.5">
                  <div className="flex-1 max-w-xs h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${selectedChar.exp}%`, background: "linear-gradient(90deg, #ff8c42, #f5a623)" }} />
                  </div>
                  <span className="text-[10px] text-muted-foreground font-mono">{selectedChar.exp}%</span>
                </div>
              </div>
              <div className="hidden md:block text-right shrink-0">
                <p className="text-[10px] text-muted-foreground">전투력</p>
                <p className="text-sm font-bold text-primary font-mono">{selectedChar.combatPower.toLocaleString()}</p>
              </div>
            </div>
          </div>
        )}

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {activeNav === "charselect" && (
            <CharacterSelectView
              characters={CHARACTERS}
              selected={selectedChar}
              onSelect={char => { setSelectedChar(char); setActiveNav("dashboard"); }}
              charTags={charTags}
              onTagToggle={handleTagToggle}
            />
          )}
          {activeNav === "dashboard" && <Dashboard char={selectedChar} />}
          {activeNav === "characters" && <CharacterView char={selectedChar} />}
          {activeNav === "equipment" && <EquipmentView char={selectedChar} />}
          {activeNav === "boss" && <BossView />}
          {activeNav === "content" && <ContentView />}
          {activeNav === "report" && <ReportView />}
        </main>
      </div>
    </div>
  );
}
